const express = require('express');
const app = express();
const PORT = 80;
const IP = "0.0.0.0";

var data = {};
//Middlewares are before routes
const reqMiddleware = (req, res, next) => {
    console.log('Req middleware');

    // if(req.method === 'POST')
    // next();

    // else
    // res.status(403).json({error: {message: `Method ${req.method} is not allowed`}})

    if(req.headers.api_key) //req.headers['API_KEY']
    {
        if(Number(req.headers.api_key) === 1234)
        next();
        else
        res.status(412).json({error: {message: "Provided API KEY isn't valid"}});
    }
    else
    res.status(403).json({error: {message: "Missing API key"}});

    next();
}

const resMiddleware = (req, res, next) => {
    console.log('Res middleware');

    res.sendDate = false; //Should or shouldn't return date back to FE

    res.setHeader("Igor", "123");
    if(res._hasBody)
    {
        data = {
            fullname: false,
            dob: false,
            sex: false
        }
    }
    next();
}

const corsMiddleware = (req, res, next) => {

    //set cors stuff
    next();
}

//Include middlewares into the server/app
app.use(reqMiddleware);
app.use(resMiddleware);
app.use(corsMiddleware);

//Routes are below
app.get('/', (req, res) => {

    data.status = "OK";
    res.status(200).json(data);
})

app.get('/currentuser', (req, res) => {
    data.fullname = 'Igor';
    data.dob = '1305',
    data.sex = 'M'

    res.status(200).json(data);
});

app.listen(PORT, IP, () => {
    console.log(`Server is listening on ${IP}:${PORT}`);
})