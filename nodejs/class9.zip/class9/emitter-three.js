const events = require('events').EventEmitter;

//Create new instance , but nothing happens with event itself
const fEvent = new events();
const sEvent = new events();

//First setup listeners on events (LISTENERS ALWAYS SHOULD BE SET BEFORE EMITTERS)
fEvent.on('activate', (data) => {
    console.log('fEvent active listener')
    console.log(data);
})

fEvent.on('deactivate', (data) => {
    console.log('fEvent deactivate listener');
    console.log(data);
})


sEvent.on('deactivate', (data) => {
    console.log('sEvent deactivate listener');
    console.log(data);
})

sEvent.on('activate', (data) => {
    console.log('sEvent activate listener')
    console.log(data);
})


//Second setup dispatchers of events
// fEvent.emit('activate', {a: 2});
// sEvent.emit('activate', {a: 3});

// fEvent.emit('deactivate', {d: 1})
// var c = 0;
// setInterval(() => {

//     if(c % 2 == 0)
//     {
//         fEvent.emit('activate', {c: c})
//         sEvent.emit('deactivate', {c: c})
//     }
//     else
//     {
//         fEvent.emit('deactivate', {c: c});
//         sEvent.emit('activate', {c: c});
//     }

//     c = c + 1;
// }, 3000)

//Global events

process.events = new events();

process.events.on('event-one', (data) => {
    console.log('Event one listener', data);
    data.a = data.a + 1;
    process.events.emit('confirm-one', data)
})

process.events.on('event-two', (data) => {
    console.log('Event two listener', data);
})


let emiter = require('./emitter-four.js');