
if(process.events)
{
    process.events.on('confirm-one', (data) => {
        console.log('Event one was called, confirm', data)
    })

    process.events.emit('event-one', {a: 5});
    process.events.emit('event-two', {b: 2})
}

