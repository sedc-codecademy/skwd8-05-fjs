const express = require('express');
const eSession = require('express-session');
const uuid = require('uuid');
const app = express();

const PORT = 80;
const IP = "0.0.0.0";

app.set('trust proxy', 1);

const session = eSession({
    secret: 'MySecretKey',
    cookie: {
        httpOnly: false,
        maxAge: 1000 * 60 * 60 * 24        
    },
    resave: false,
    saveUninitialized: false,
    name: 'MainSession',
    genid: () => {
        return uuid.v4();
    },
    //store: eSession.MemoryStore - MemoryStore is default, otherwise specify where to store the session
});

app.use(session); //Includes the session to the server and becomes active on all routes

app.get('/', (req, res) => {
    console.log(req.session.id);
    //res.status(200).send({a: 1}) "{a:1}"
    //res.sendFile()

    return res.status(200).json({success: "Hi there"});
})

app.get('/count', (req, res) => {
    req.session.count = req.session.count ? req.session.count + 1 : 1;
    return res.status(200).json({count: req.session.count});
})

app.get('/about', (req, res) => {
    req.session.biloso = req.session.biloso ? req.session.biloso + 1 : 1;
    return res.status(200).json({count: req.session.biloso});
})

app.listen(PORT, IP, () => {
    console.log(`Server is running on ${IP}:${PORT}`)
})

//req.session = {}

// req.session = {
//     id: 12312312313123,
//     callMe = () => {
//         console.log('I was called');
//     }
// };

// req.session.callMe();
