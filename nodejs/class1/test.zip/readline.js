const readline = require("readline");
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// rl.question("What is your name? ", (name) => {
//     console.log(`Your name is ${name}`);

//     rl.question("Where do you live? ", (city) => {
//         console.log(`You live in ${city}`);
//         rl.close();
//     })
    
// });

rl.on('close', () => {
    console.log("\n End of questioning");
    process.exit(0);
});

module.exports = rl;