let a = 10;
const b = 10;
var c = 50;

console.log(a, b, c);

//window
//console.log(process);

// setInterval(() => {
//     console.log('CPU', process.cpuUsage());
//     console.log('MEM', process.memoryUsage());
//     console.log('HR', process.hrtime());
// }, 5000);

//environment variables
/*
key prod = 123456
key dev = 567890
*/

//console.log(process.argv)
// let [,, env, key, ...arg] = process.argv;

// function getEnvironmentValues(variable)
// {
//     if(variable)
//     return variable.split("=")[1];
//     else
//     return false;
// }

// env = getEnvironmentValues(env) || 'dev';
// key = getEnvironmentValues(key);
// console.log(env, key);

//User Input / Output
const rl = require('./readline.js');

rl.question('This is something new? ', (answer) => {
    console.log(answer);
    rl.close();
})